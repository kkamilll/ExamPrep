# 📌 2019_zima - e14-07-19_01 (E.14 (Tworzenie aplikacji internetowych i baz danych))

> **Temat zadania:** 2019 zima   e14 07 19 01  
> **Kwalifikacja:** E.14 (Tworzenie aplikacji internetowych i baz danych)  
> **Technologie:** CSS3, PHP (mysqli), MySQL

---

## 📖 Opis zadania i co zostało zrobione

Zadanie praktyczne z przygotowania do egzaminu zawodowego obejmujące tworzenie aplikacji internetowej, arkusza stylów CSS oraz relacyjnej bazy danych.

### Główne elementy rozwiązania:
- Przygotowanie responsywnego arkusza stylów CSS zgodnie z wytycznymi arkusza.
- Utworzenie tabel, relacji oraz przygotowanie poprawnych kwerend SQL (SELECT, INSERT, UPDATE).
- Oprogramowanie skryptu backendowego w PHP (mysqli) do komunikacji z bazą danych MySQL.

---

## 📁 Pliki w tym zadaniu

- 📄 **Arkusz PDF:** `E.14-07-19.01.pdf`
- 🐘 **Skrypty PHP:** `sklep.php`
- 💾 **Baza / Kwerendy SQL:** `baza.sql`
- 📝 **Pliki tekstowe / Kwerendy:** `kwerendy.txt`
- 🎨 **Style CSS:** `styl1.css`

---

## 🚀 Instrukcja krok po kroku (co zrobić po pobraniu)

1. **Rozpakuj pobrane archiwum ZIP** do dowolnego folderu.

2. **Import bazy danych:**
   - Uruchom lokalny serwer MySQL (np. w panelu XAMPP).
   - Otwórz w przeglądarce `http://localhost/phpmyadmin`.
   - Utwórz nową bazę danych i zaimportuj plik SQL (`baza.sql`).

3. **Uruchomienie PHP:**
   - Skopiuj ten rozpakowany folder do katalogu `C:\xampp\htdocs\e14-07-19_01`.
   - Uruchom moduł **Apache** w XAMPP.
   - Otwórz w przeglądarce adres: `http://localhost/e14-07-19_01/sklep.php`.

---

*Powodzenia w nauce i na egzaminie zawodowym! 🎓*
